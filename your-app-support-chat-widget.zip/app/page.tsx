import { ChatWidget } from "@/components/chat/chat-widget"

export default function Page() {
  return (
    <main className="min-h-dvh bg-background md:flex md:items-center md:justify-center md:py-8">
      <ChatWidget />
    </main>
  )
}
