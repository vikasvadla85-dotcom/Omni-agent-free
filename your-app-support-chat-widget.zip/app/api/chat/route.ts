import Anthropic from "@anthropic-ai/sdk"
import type { MessageParam } from "@anthropic-ai/sdk/resources/messages"
import { NextResponse } from "next/server"
import { SUPPORT_SYSTEM_PROMPT } from "@/lib/support-system-prompt"
import {
  createTicket,
  escalateToHuman,
  getAccountStatus,
  logInteraction,
  searchKnowledgeBase,
  SUPPORT_TOOL_DEFINITIONS,
  type SupportCategory,
} from "@/lib/support-tools"

const MODEL = "claude-sonnet-5"
const MAX_TOKENS = 1024
const MAX_TOOL_ITERATIONS = 6

interface ChatRequestBody {
  user_id: string
  message: string
  history: unknown[]
}

function runTool(name: string, input: Record<string, unknown>) {
  switch (name) {
    case "search_knowledge_base":
      return searchKnowledgeBase(String(input.query ?? ""))
    case "get_account_status":
      return getAccountStatus(
        String(input.user_id ?? ""),
        input.topic as "subscription" | "billing_history" | "account_access",
      )
    case "create_ticket":
      return createTicket(
        String(input.user_id ?? ""),
        input.category as SupportCategory,
        String(input.summary ?? ""),
      )
    case "escalate_to_human":
      return escalateToHuman(
        String(input.user_id ?? ""),
        input.category as SupportCategory,
        String(input.reason ?? ""),
      )
    case "log_interaction":
      return logInteraction(
        String(input.user_id ?? ""),
        input.category as SupportCategory,
        Boolean(input.resolved),
      )
    default:
      return { error: `Unknown tool: ${name}` }
  }
}

export async function POST(req: Request) {
  const apiKey = process.env.ANTHROPIC_API_KEY_2 || process.env.ANTHROPIC_API_KEY
  if (!apiKey) {
    return NextResponse.json(
      { error: "ANTHROPIC_API_KEY_2 is not configured on the server." },
      { status: 500 },
    )
  }

  let body: ChatRequestBody
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 })
  }

  const { user_id, message, history } = body
  if (!user_id || typeof message !== "string" || !message.trim()) {
    return NextResponse.json({ error: "user_id and message are required." }, { status: 400 })
  }

  const anthropic = new Anthropic({ apiKey })

  const messages: MessageParam[] = [
    ...((Array.isArray(history) ? history : []) as MessageParam[]),
    { role: "user", content: message },
  ]

  let escalated = false
  let ticketId: string | null = null
  let finalReply = ""

  try {
    for (let iteration = 0; iteration < MAX_TOOL_ITERATIONS; iteration++) {
      const response = await anthropic.messages.create({
        model: MODEL,
        max_tokens: MAX_TOKENS,
        system: SUPPORT_SYSTEM_PROMPT,
        tools: SUPPORT_TOOL_DEFINITIONS,
        messages,
      })

      messages.push({ role: "assistant", content: response.content })

      if (response.stop_reason !== "tool_use") {
        finalReply = response.content
          .filter((block) => block.type === "text")
          .map((block) => (block.type === "text" ? block.text : ""))
          .join("\n")
          .trim()
        break
      }

      const toolUseBlocks = response.content.filter((block) => block.type === "tool_use")
      const toolResults = toolUseBlocks.map((block) => {
        if (block.type !== "tool_use") return null
        const result = runTool(block.name, (block.input ?? {}) as Record<string, unknown>)

        if (block.name === "escalate_to_human") escalated = true
        if (block.name === "create_ticket" && result && "ticket_id" in result) {
          ticketId = (result as { ticket_id: string }).ticket_id
        }

        return {
          type: "tool_result" as const,
          tool_use_id: block.id,
          content: JSON.stringify(result),
        }
      })

      messages.push({
        role: "user",
        content: toolResults.filter((r) => r !== null) as NonNullable<(typeof toolResults)[number]>[],
      })

      if (iteration === MAX_TOOL_ITERATIONS - 1) {
        finalReply =
          "I'm having trouble finishing that up on my end — let me connect you with a member of our support team."
        escalated = true
      }
    }
  } catch (error) {
    console.error("[v0] chat route error:", error)
    return NextResponse.json(
      { error: "Failed to generate a response from the support assistant." },
      { status: 502 },
    )
  }

  return NextResponse.json({
    reply: finalReply || "I'm here to help — could you tell me a bit more about what's going on?",
    history: messages,
    escalated,
    ticket_id: ticketId,
  })
}
