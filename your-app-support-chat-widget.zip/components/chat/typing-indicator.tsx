export function TypingIndicator() {
  return (
    <div className="flex items-center gap-2" role="status" aria-label="Assistant is typing">
      <div className="flex items-center gap-1 rounded-3xl rounded-bl-md bg-muted px-4 py-3">
        <span className="size-1.5 animate-bounce rounded-full bg-muted-foreground/60 [animation-delay:-0.3s]" />
        <span className="size-1.5 animate-bounce rounded-full bg-muted-foreground/60 [animation-delay:-0.15s]" />
        <span className="size-1.5 animate-bounce rounded-full bg-muted-foreground/60" />
      </div>
    </div>
  )
}
