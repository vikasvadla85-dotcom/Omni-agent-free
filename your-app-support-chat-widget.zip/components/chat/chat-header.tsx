import { MessageCircleHeart } from "lucide-react"

export function ChatHeader() {
  return (
    <header className="flex items-center gap-3 border-b border-border bg-card px-4 py-3.5">
      <div className="flex size-10 shrink-0 items-center justify-center rounded-2xl bg-primary text-primary-foreground">
        <MessageCircleHeart className="size-5" aria-hidden="true" />
      </div>

      <div className="flex min-w-0 flex-1 flex-col">
        <h1 className="truncate text-[15px] font-semibold text-foreground">YourApp Support</h1>
        <p className="text-xs text-muted-foreground">We usually reply in a minute</p>
      </div>

      {/* Always-visible AI disclosure badge — required for compliance, must never be hidden in a menu */}
      <span className="shrink-0 rounded-full bg-accent px-2.5 py-1 text-[11px] font-semibold tracking-wide text-accent-foreground">
        AI Assistant
      </span>
    </header>
  )
}
