interface FeedbackToastProps {
  message: string | null
}

export function FeedbackToast({ message }: FeedbackToastProps) {
  if (!message) return null

  return (
    <div
      className="pointer-events-none absolute inset-x-0 bottom-24 z-10 flex justify-center px-4"
      role="status"
      aria-live="polite"
    >
      <div className="rounded-full bg-foreground px-4 py-2 text-xs font-medium text-background shadow-lg">
        {message}
      </div>
    </div>
  )
}
