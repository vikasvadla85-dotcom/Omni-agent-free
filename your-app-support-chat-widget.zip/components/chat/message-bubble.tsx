import { AlertCircle, ThumbsDown, ThumbsUp } from "lucide-react"
import type { ChatMessage } from "@/lib/chat-types"
import { cn } from "@/lib/utils"

interface MessageBubbleProps {
  message: ChatMessage
  onFeedback: (id: string, value: "up" | "down") => void
}

export function MessageBubble({ message, onFeedback }: MessageBubbleProps) {
  if (message.role === "error") {
    return (
      <div className="flex items-start gap-2 rounded-2xl bg-destructive/10 px-4 py-3 text-sm text-destructive">
        <AlertCircle className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
        <p className="leading-relaxed">{message.text}</p>
      </div>
    )
  }

  const isUser = message.role === "user"

  return (
    <div className={cn("flex flex-col gap-1.5", isUser ? "items-end" : "items-start")}>
      <div
        className={cn(
          "max-w-[85%] rounded-3xl px-4 py-3 text-[15px] leading-relaxed text-pretty",
          isUser
            ? "rounded-br-md bg-primary text-primary-foreground"
            : "rounded-bl-md bg-muted text-foreground",
        )}
      >
        {message.text}
      </div>

      {!isUser && message.ticketId && (
        <span className="ml-1 inline-flex items-center rounded-full bg-accent px-2.5 py-1 text-xs font-medium text-accent-foreground">
          Ticket {message.ticketId}
        </span>
      )}

      {!isUser && (
        <div className="ml-1 flex items-center gap-1">
          <button
            type="button"
            aria-label="Good response"
            aria-pressed={message.feedback === "up"}
            onClick={() => onFeedback(message.id, "up")}
            className={cn(
              "flex size-7 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-muted hover:text-foreground",
              message.feedback === "up" && "bg-accent text-accent-foreground",
            )}
          >
            <ThumbsUp className="size-3.5" aria-hidden="true" />
          </button>
          <button
            type="button"
            aria-label="Bad response"
            aria-pressed={message.feedback === "down"}
            onClick={() => onFeedback(message.id, "down")}
            className={cn(
              "flex size-7 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-muted hover:text-foreground",
              message.feedback === "down" && "bg-destructive/15 text-destructive",
            )}
          >
            <ThumbsDown className="size-3.5" aria-hidden="true" />
          </button>
        </div>
      )}
    </div>
  )
}
