import { ArrowUp } from "lucide-react"
import type { KeyboardEvent } from "react"
import { Button } from "@/components/ui/button"

interface ChatInputProps {
  value: string
  onChange: (value: string) => void
  onSend: () => void
  disabled: boolean
}

export function ChatInput({ value, onChange, onSend, disabled }: ChatInputProps) {
  function handleKeyDown(event: KeyboardEvent<HTMLTextAreaElement>) {
    // Avoid submitting while an IME composition is in progress (CJK input),
    // and treat Safari's unreliable keyCode 229 the same way.
    if (event.key === "Enter" && !event.shiftKey && !event.nativeEvent.isComposing && event.keyCode !== 229) {
      event.preventDefault()
      if (!disabled && value.trim()) {
        onSend()
      }
    }
  }

  return (
    <div className="flex items-end gap-2 border-t border-border bg-card px-3 py-3">
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={handleKeyDown}
        disabled={disabled}
        placeholder="Type a message…"
        rows={1}
        aria-label="Message"
        className="max-h-28 min-h-10 flex-1 resize-none rounded-2xl border border-input bg-background px-4 py-2.5 text-[15px] leading-relaxed text-foreground placeholder:text-muted-foreground outline-none focus-visible:ring-3 focus-visible:ring-ring/40 disabled:opacity-60"
      />
      <Button
        type="button"
        size="icon-lg"
        aria-label="Send message"
        disabled={disabled || !value.trim()}
        onClick={onSend}
        className="rounded-full"
      >
        <ArrowUp className="size-4.5" aria-hidden="true" />
      </Button>
    </div>
  )
}
