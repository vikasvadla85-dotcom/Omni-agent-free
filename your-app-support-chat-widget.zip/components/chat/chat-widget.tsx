"use client"

import { useEffect, useRef, useState } from "react"
import { ChatHeader } from "@/components/chat/chat-header"
import { MessageBubble } from "@/components/chat/message-bubble"
import { TypingIndicator } from "@/components/chat/typing-indicator"
import { ChatInput } from "@/components/chat/chat-input"
import { EscalationBanner } from "@/components/chat/escalation-banner"
import { FeedbackToast } from "@/components/chat/feedback-toast"
import type { ChatApiResponse, ChatMessage } from "@/lib/chat-types"

const SUPPORT_API_URL = process.env.NEXT_PUBLIC_SUPPORT_API_URL || "/api/chat"
const REQUEST_TIMEOUT_MS = 15000

function createId() {
  return typeof crypto !== "undefined" && "randomUUID" in crypto
    ? crypto.randomUUID()
    : Math.random().toString(36).slice(2)
}

export function ChatWidget() {
  const [userId] = useState(() => createId())
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: createId(),
      role: "agent",
      text: "Hi there! I'm YourApp's AI support assistant. What can I help you with today?",
    },
  ])
  // The client never inspects or mutates `history` — it's kept exactly as the
  // server returns it and round-tripped on the next request.
  const [history, setHistory] = useState<unknown[]>([])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [escalated, setEscalated] = useState(false)
  const [toast, setToast] = useState<string | null>(null)

  const scrollAnchorRef = useRef<HTMLDivElement>(null)
  const toastTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  useEffect(() => {
    scrollAnchorRef.current?.scrollIntoView({ behavior: "smooth", block: "end" })
  }, [messages, isLoading])

  useEffect(() => {
    return () => {
      if (toastTimeoutRef.current) clearTimeout(toastTimeoutRef.current)
    }
  }, [])

  function showToast(text: string) {
    setToast(text)
    if (toastTimeoutRef.current) clearTimeout(toastTimeoutRef.current)
    toastTimeoutRef.current = setTimeout(() => setToast(null), 2000)
  }

  function handleFeedback(messageId: string, value: "up" | "down") {
    setMessages((prev) => prev.map((m) => (m.id === messageId ? { ...m, feedback: value } : m)))
    // TODO: POST this to your feedback endpoint
    showToast("Thanks for the feedback")
  }

  async function handleSend() {
    const text = input.trim()
    if (!text || isLoading) return

    const userMessage: ChatMessage = { id: createId(), role: "user", text }
    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    const controller = new AbortController()
    const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS)

    try {
      const res = await fetch(SUPPORT_API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ user_id: userId, message: text, history }),
        signal: controller.signal,
      })

      if (!res.ok) throw new Error(`Request failed with status ${res.status}`)

      const data: ChatApiResponse = await res.json()

      setHistory(data.history)
      setMessages((prev) => [
        ...prev,
        {
          id: createId(),
          role: "agent",
          text: data.reply,
          ticketId: data.ticket_id,
        },
      ])
      if (data.escalated) setEscalated(true)
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          id: createId(),
          role: "error",
          text: "Having trouble connecting — please try again.",
        },
      ])
    } finally {
      clearTimeout(timeout)
      setIsLoading(false)
    }
  }

  return (
    <div className="relative mx-auto flex h-dvh w-full max-w-md flex-col bg-background">
      <ChatHeader />

      <div className="flex-1 overflow-y-auto px-4 py-4">
        <div className="flex flex-col gap-4">
          {messages.map((message) => (
            <MessageBubble key={message.id} message={message} onFeedback={handleFeedback} />
          ))}
          {isLoading && <TypingIndicator />}
          <div ref={scrollAnchorRef} />
        </div>
      </div>

      <FeedbackToast message={toast} />

      {escalated && <EscalationBanner />}

      <ChatInput value={input} onChange={setInput} onSend={handleSend} disabled={isLoading} />
    </div>
  )
}
