import { UserRound } from "lucide-react"

export function EscalationBanner() {
  return (
    <div className="flex items-center gap-2.5 border-t border-border bg-accent px-4 py-2.5 text-accent-foreground">
      <UserRound className="size-4 shrink-0" aria-hidden="true" />
      <p className="text-xs leading-relaxed">
        Connected to a member of our support team — they&apos;ll follow up shortly.
      </p>
    </div>
  )
}
