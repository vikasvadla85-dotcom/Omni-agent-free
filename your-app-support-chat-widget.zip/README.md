# YourApp Support Chat Widget

A self-contained Next.js app: a mobile-first AI support chat widget with the
agent logic running as a serverless API route (`app/api/chat/route.ts`) — no
separate backend to host.

## Required environment variable

Before this works in production, set `ANTHROPIC_API_KEY` in your Vercel
project settings (Project → Settings → Environment Variables). It is read
**server-side only** in the API route and must never be prefixed with
`NEXT_PUBLIC_` or referenced from client code.

## Optional environment variable

- `NEXT_PUBLIC_SUPPORT_API_URL` — override the chat endpoint the client calls.
  Defaults to the relative path `/api/chat` (the built-in route), so this only
  needs to be set if you want to point the widget at a different backend.
