export type ChatRole = "user" | "agent" | "error"

export interface ChatMessage {
  id: string
  role: ChatRole
  text: string
  ticketId?: string | null
  feedback?: "up" | "down" | null
}

export interface ChatApiRequest {
  user_id: string
  message: string
  history: unknown[]
}

export interface ChatApiResponse {
  reply: string
  history: unknown[]
  escalated: boolean
  ticket_id: string | null
}
