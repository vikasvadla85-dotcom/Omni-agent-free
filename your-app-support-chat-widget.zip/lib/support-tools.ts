// Stub tool implementations for the support assistant tool-use loop.
// These return fake-but-realistic data so the model's behavior stays
// consistent with the system prompt without requiring real backend systems.

export type SupportCategory = "login" | "billing" | "how_to" | "bug" | "complaint"

const KNOWLEDGE_BASE: Record<string, string> = {
  notification: "Go to Settings > Notifications and toggle off what you don't want.",
  password: "Tap 'Forgot password' on the login screen to get a reset link by email.",
  cancel:
    "Subscriptions can be cancelled from Settings > Subscription > Cancel. Cancellation takes effect at the end of the current billing period.",
}

function createTicketId() {
  return `TCK-${crypto.randomUUID().slice(0, 8).toUpperCase()}`
}

export function searchKnowledgeBase(query: string) {
  const q = query.toLowerCase()
  const matchKey = Object.keys(KNOWLEDGE_BASE).find((keyword) => q.includes(keyword))
  if (!matchKey) return { found: false, answer: null }
  return { found: true, answer: KNOWLEDGE_BASE[matchKey] }
}

export function getAccountStatus(
  userId: string,
  topic: "subscription" | "billing_history" | "account_access",
) {
  return {
    user_id: userId,
    topic,
    subscription_plan: "Pro Monthly",
    renewal_date: "2026-10-01",
    last_charge: { amount: "$9.99", date: "2026-09-01" },
  }
}

export function createTicket(userId: string, category: SupportCategory, summary: string) {
  return {
    ticket_id: createTicketId(),
    category,
    summary,
  }
}

export function escalateToHuman(userId: string, category: SupportCategory, reason: string) {
  return {
    escalated: true,
    category,
    reason,
  }
}

export function logInteraction(userId: string, category: SupportCategory, resolved: boolean) {
  return {
    logged: true,
    category,
    resolved,
  }
}

export const SUPPORT_TOOL_DEFINITIONS = [
  {
    name: "search_knowledge_base",
    description:
      "Search the help center knowledge base for an answer to a 'how do I' or troubleshooting question. Call this before answering how-to questions.",
    input_schema: {
      type: "object" as const,
      properties: {
        query: { type: "string", description: "The user's question or topic to search for." },
      },
      required: ["query"],
    },
  },
  {
    name: "get_account_status",
    description:
      "Look up the current user's account status. Only call this after the app's login session has confirmed identity, for account-specific questions.",
    input_schema: {
      type: "object" as const,
      properties: {
        user_id: { type: "string" },
        topic: {
          type: "string",
          enum: ["subscription", "billing_history", "account_access"],
        },
      },
      required: ["user_id", "topic"],
    },
  },
  {
    name: "create_ticket",
    description:
      "Create a support ticket for a resolved or in-progress issue that needs a reference number.",
    input_schema: {
      type: "object" as const,
      properties: {
        user_id: { type: "string" },
        category: { type: "string", enum: ["login", "billing", "how_to", "bug", "complaint"] },
        summary: { type: "string", description: "A short summary of the issue." },
      },
      required: ["user_id", "category", "summary"],
    },
  },
  {
    name: "escalate_to_human",
    description:
      "Escalate the conversation to a human support agent. Call this immediately, with no workaround attempts, for refunds, cancellations with financial impact, account deletion, legal threats, minor safety issues, angry or repeat-issue users, or after a tool fails twice.",
    input_schema: {
      type: "object" as const,
      properties: {
        user_id: { type: "string" },
        category: { type: "string", enum: ["login", "billing", "how_to", "bug", "complaint"] },
        reason: { type: "string", description: "Why this is being escalated." },
      },
      required: ["user_id", "category", "reason"],
    },
  },
  {
    name: "log_interaction",
    description:
      "Log the outcome of the conversation. Call this right before your final reply in a conversation that's wrapping up, tagged with the category.",
    input_schema: {
      type: "object" as const,
      properties: {
        user_id: { type: "string" },
        category: { type: "string", enum: ["login", "billing", "how_to", "bug", "complaint"] },
        resolved: { type: "boolean" },
      },
      required: ["user_id", "category", "resolved"],
    },
  },
]
